// LOCAL ONLY (agent `library`): not part of the change; deleted before hand-off.
// Own port, so this worktree's specs never reuse another worktree's dev server.
import base from './playwright.config';
import { defineConfig } from '@playwright/test';

const launchOptions = { executablePath: '/opt/pw-browsers/chromium' };

export default defineConfig({
  ...base,
  use: { ...base.use, baseURL: 'http://localhost:14277', launchOptions, trace: 'off' },
  projects: (base.projects ?? []).map((p) => ({ ...p, use: { ...p.use, launchOptions } })),
  webServer: {
    command: 'pnpm exec vite --port 14277 --strictPort',
    url: 'http://localhost:14277',
    reuseExistingServer: true,
    timeout: 180_000,
  },
});
